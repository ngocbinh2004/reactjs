export default function PageNotFound() {
  return (
    <div>
      <h1>PageNotFound</h1>
    </div>
  );
}
