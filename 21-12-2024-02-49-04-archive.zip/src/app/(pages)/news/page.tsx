export default function News() {
  return (
    <div>
      <h1>News</h1>
    </div>
  );
}
